package FypSystem;

/**
 *
 * @author mihirbhupathiraju
 */
public abstract class UserAction {

    /**
     *
     */
    protected User user;

    /**
     *
     * @param user
     */
    public UserAction(User user){
        this.user = user;
    }

    /**
     *
     */
    public abstract void act (); 
}
