package FypSystem;

/**
 *
 * @author mihirbhupathiraju
 */
public class RequestRecordListDisplayManager extends DisplayManager {

    /**
     *
     */
    public RequestRecordListDisplayManager() {};

    
    /** 
     * @param o
     */
    public void manage(Object o) {
        RequestRecordList requestRecordList = (RequestRecordList) o;
        RequestRecordListDisplayAll display = new RequestRecordListDisplayAll();
        display.display(requestRecordList.requestRecordList);
    }

    /**
     *
     * @param o
     * @return
     */
    public boolean check (Object o) {
        RequestRecordList requestRecordList = (RequestRecordList) o;
        return (requestRecordList.getListSize()!=0);
    }
}
