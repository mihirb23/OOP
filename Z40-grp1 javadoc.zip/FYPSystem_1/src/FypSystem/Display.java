package FypSystem;

/**
 *
 * @author mihirbhupathiraju
 */
public abstract class Display {

    /**
     *
     * @param o
     */
    public abstract void display(Object o);
}
