package FypSystem;
import java.util.*;

/**
 *
 * @author mihirbhupathiraju
 */
public class RequestRecordList{
    ArrayList<RequestRecord> requestRecordList = new ArrayList<RequestRecord>();

    /**
     *
     * @return
     */
    public ArrayList<RequestRecord>  getRequestList() {return this.requestRecordList;}

    /**
     *
     * @param requestRecord
     */
    public void addRequestRecord (RequestRecord requestRecord) { this.requestRecordList.add(requestRecord);}

    /**
     *
     * @param index
     * @return
     */
    public RequestRecord getRequestRecord(int index) { return this.requestRecordList.get(index);}

    /**
     *
     * @return
     */
    public int getListSize() {return this.requestRecordList.size();}
}

