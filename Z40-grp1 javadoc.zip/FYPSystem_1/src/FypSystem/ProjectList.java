package FypSystem;
import java.util.ArrayList;

/**
 *
 * @author mihirbhupathiraju
 */
public class ProjectList {
    ArrayList<Project> projectList = new ArrayList<Project>();

    /**
     *
     * @param project
     */
    public void addProject(Project project) {this.projectList.add(project);}

    /**
     *
     * @param project
     */
    public void removeProject(Project project) {this.projectList.remove(project);}

    /**
     *
     * @param projectId
     * @return
     */
    public Project getProject(int projectId) { return this.projectList.get(projectId); }

    /**
     *
     * @return
     */
    public ArrayList<Project> getProjectList () {return this.projectList;}

    /**
     *
     * @return
     */
    public int getListSize() {return this.projectList.size();}
}
