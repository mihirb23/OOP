package FypSystem;

/**
 *
 * @author mihirbhupathiraju
 */
public abstract class RequestAction {

    /**
     *
     */
    public String name;

    /**
     *
     */
    public abstract void display();

    /**
     *
     * @return
     */
    public abstract boolean approve();

    /**
     *
     * @return
     */
    public abstract boolean reject();
}

