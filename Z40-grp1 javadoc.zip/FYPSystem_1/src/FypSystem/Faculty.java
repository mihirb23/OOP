package FypSystem;

/**
 *
 * @author mihirbhupathiraju
 */
public abstract class Faculty extends User {
    private ProjectList supervisingProject;
    private ProjectList myProject;

    /**
     *
     * @param userId
     * @param name
     * @param password
     */
    public Faculty(String userId, String name, String password) {
        super(userId, name, password);
        supervisingProject = new ProjectList();
        myProject = new ProjectList();
    }

    /**
     *
     */
    public abstract void prompt(); 

    /**
     *
     * @return
     */
    public ProjectList getSupervisingProject() {return this.supervisingProject;}

    /**
     *
     * @return
     */
    public ProjectList getMyProject() {return this.myProject; }
    
}
