package FypSystem;
enum RecordStatus {PENDING, APPROVED, REJECTED};

/**
 *
 * @author mihirbhupathiraju
 */
public class RequestRecord
{

    /**
     *
     */
    public String requesterId;

    /**
     *
     */
    public String recipientId;

    /**
     *
     */
    public RecordStatus recordStatus;

    /**
     *
     */
    public RequestAction requestAction;

    /**
     *
     * @param requestAct
     * @param requesterId
     * @param recipientId
     */
    public RequestRecord(RequestAction requestAct, String requesterId, String recipientId) {
        this.setRecipientId(recipientId);
        this.setRequesterId(requesterId);
        this.setStatus(RecordStatus.PENDING);
        this.setRequestAct(requestAct);
    }; 

    
    /** 
     * @param tstatus
     * @return boolean
     */
    public boolean isStatus (RecordStatus tstatus) {
        return (tstatus.equals(this.recordStatus));
    }; 

    /**
     *
     * @param recipientId
     */
    public void setRecipientId (String recipientId) { this.recipientId = recipientId; };

    /**
     *
     * @param requesterId
     */
    public void setRequesterId (String requesterId) { this.requesterId = requesterId; };

    /**
     *
     * @param t
     */
    public void setStatus(RecordStatus t) { this.recordStatus = t;}; //for reject/approve request//for reject/approve request

    /**
     *
     * @param requestAction
     */
    public void setRequestAct(RequestAction requestAction) {this.requestAction = requestAction;};
    
    /**
     *
     * @return
     */
    public String getRecipientId() {return this.recipientId;}

    /**
     *
     * @return
     */
    public String getRequesterId() {return this.requesterId;}

    /**
     *
     * @return
     */
    public RecordStatus getStatus() {return this.recordStatus;}
}

























