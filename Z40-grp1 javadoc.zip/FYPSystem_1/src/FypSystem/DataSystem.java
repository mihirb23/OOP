package FypSystem;

/**
 *
 * @author mihirbhupathiraju
 */
public class DataSystem {
    
    /**
     *
     */
    protected static ProjectList allProjectList = new ProjectList();

    /**
     *
     */
    protected static RequestRecordList allRequestList = new RequestRecordList();

    /**
     *
     */
    protected static UserList allUserList = new UserList();

    /**
     *
     * @return
     */
    public static ProjectList getAllProjectList() {return DataSystem.allProjectList;}

    /**
     *
     * @return
     */
    public static RequestRecordList getAllRequestList () {return DataSystem.allRequestList;}

    /**
     *
     * @return
     */
    public static UserList getAllUserList() {return DataSystem.allUserList;}
}

