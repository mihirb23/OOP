package FypSystem;

/**
 *
 * @author mihirbhupathiraju
 */
public interface AppInterface {

    /**
     *
     */
    public void prompt();
}