package FypSystem;

/**
 *
 * @author mihirbhupathiraju
 */
public abstract class User {

    /**
     *
     */
    protected String userId;

    /**
     *
     */
    protected String name;
    private String password;
    private String myCoordinator;

    /**
     *
     */
    protected RequestRecordList requestList;
    UserAction currentAction = null;

    /**
     *
     * @param userId
     * @param name
     * @param password
     */
    public User(String userId, String name, String password) {
        this.userId = (userId);
        this.name = (name);
        this.setPassword(password);
        this.myCoordinator = "ASFLI";
        this.requestList  = new RequestRecordList() ;
    }
    
    /**
     *
     * @param password
     */
    protected void setPassword(String password) { this.password = password; }

    /**
     *
     * @return
     */
    public String getUserId(){return this.userId;}

    /**
     *
     * @return
     */
    public String getName(){return this.name;}

    /**
     *
     * @return
     */
    public String getMyCoordinator() {return this.myCoordinator;}

    /**
     *
     * @return
     */
    public RequestRecordList getMyRequestList() {return this.requestList;}
    
    /** 
     * @param password
     * @return boolean
     */
    public boolean verifyPassword(String password) {
        return this.password.equals(password);
    }

    /**
     *
     */
    public abstract void prompt();
    
}