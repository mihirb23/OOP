package FypSystem;

/**
 *
 * @author mihirbhupathiraju
 */
public abstract class DisplayManager {

    /**
     *
     * @param o
     */
    public abstract void manage (Object o);
}