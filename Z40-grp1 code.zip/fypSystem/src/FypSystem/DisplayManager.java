package FypSystem;

public abstract class DisplayManager {
    public abstract void manage (Object o);
}