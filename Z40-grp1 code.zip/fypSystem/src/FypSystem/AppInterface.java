package FypSystem;

public interface AppInterface {
    public void prompt();
}