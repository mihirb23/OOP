package FypSystem;

public abstract class Display {
    public abstract void display(Object o);
}
